package com.emoniph.witchery.brewing;


public class EffectLevel {

   private final int level;


   public EffectLevel(int level) {
      this.level = level;
   }

   public int getLevel() {
      return this.level;
   }
}
