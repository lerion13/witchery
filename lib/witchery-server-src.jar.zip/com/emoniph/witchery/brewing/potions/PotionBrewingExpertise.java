package com.emoniph.witchery.brewing.potions;

import com.emoniph.witchery.brewing.potions.PotionBase;

public class PotionBrewingExpertise extends PotionBase {

   public PotionBrewingExpertise(int id, int color) {
      super(id, color);
   }
}
