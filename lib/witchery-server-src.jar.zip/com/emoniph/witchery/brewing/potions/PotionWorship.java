package com.emoniph.witchery.brewing.potions;

import com.emoniph.witchery.brewing.potions.PotionBase;

public class PotionWorship extends PotionBase {

   public PotionWorship(int id, int color) {
      super(id, color);
   }
}
