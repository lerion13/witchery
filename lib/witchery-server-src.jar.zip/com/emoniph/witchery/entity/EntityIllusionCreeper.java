package com.emoniph.witchery.entity;

import com.emoniph.witchery.entity.EntityIllusion;
import net.minecraft.world.World;

public class EntityIllusionCreeper extends EntityIllusion {

   public EntityIllusionCreeper(World world) {
      super(world);
   }
}
