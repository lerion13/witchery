package com.emoniph.witchery.entity;

import com.emoniph.witchery.Witchery;
import com.emoniph.witchery.entity.EntityLilith;
import com.emoniph.witchery.util.ChatUtil;
import com.emoniph.witchery.util.Coord;
import com.emoniph.witchery.util.ParticleEffect;
import com.emoniph.witchery.util.SoundEffect;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityFollower extends EntityTameable {

   int transformCount;


   public EntityFollower(World world) {
      super(world);
      this.setSize(0.6F, 1.8F);
      this.getNavigator().setCanSwim(true);
      this.getNavigator().setAvoidsWater(false);
      super.tasks.addTask(1, new EntityAISwimming(this));
      super.tasks.addTask(2, new EntityAIMoveTowardsRestriction(this, 2.0D));
      super.tasks.addTask(3, new EntityAIFollowOwner(this, 1.0D, 2.0F, 4.0F));
      super.tasks.addTask(4, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.3D);
   }

   public EntityAgeable createChild(EntityAgeable lover) {
      return null;
   }

   public String getCommandSenderName() {
      switch(this.getFollowerType()) {
      case 0:
         return Witchery.resource("entity.witchery.follower.elle.name");
      default:
         return super.getCommandSenderName();
      }
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(18, Integer.valueOf(0));
   }

   public int getFollowerType() {
      return super.dataWatcher.getWatchableObjectInt(18);
   }

   public void setFollowerType(int followerType) {
      super.dataWatcher.updateObject(18, Integer.valueOf(followerType));
      if(followerType == 0) {
         super.isImmuneToFire = true;
      }

   }

   protected int decreaseAirSupply(int par1) {
      return this.getFollowerType() == 0?par1:super.decreaseAirSupply(par1);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   private boolean isCourseTraversable(double waypointX, double waypointY, double waypointZ, double p_70790_7_) {
      double d4 = (waypointX - super.posX) / p_70790_7_;
      double d5 = (waypointY - super.posY) / p_70790_7_;
      double d6 = (waypointZ - super.posZ) / p_70790_7_;
      AxisAlignedBB axisalignedbb = super.boundingBox.copy();

      for(int i = 1; (double)i < p_70790_7_; ++i) {
         axisalignedbb.offset(d4, d5, d6);
         if(!super.worldObj.getCollidingBoundingBoxes(this, axisalignedbb).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   protected void updateAITasks() {
      super.updateAITasks();
      if(!super.worldObj.isRemote && super.ticksExisted % 10 == 1 && this.getFollowerType() == 0) {
         this.doElleAI();
      }

   }

   public void doElleAI() {
      if(this.hasHome()) {
         if(this.isWithinHomeDistanceCurrentPosition()) {
            ++this.transformCount;
            if(this.transformCount == 20) {
               EntityLivingBase i = this.getOwner();
               if(i != null && i instanceof EntityPlayer) {
                  ChatUtil.sendTranslated(EnumChatFormatting.DARK_PURPLE, (EntityPlayer)i, "item.witchery:glassgoblet.lilithquestsummon", new Object[0]);
                  SoundEffect.WITCHERY_MOB_LILITH_TALK.playAt((EntityLiving)this);
               }
            } else if(this.transformCount == 40) {
               this.transformCount = 0;
               ParticleEffect.INSTANT_SPELL.send(SoundEffect.FIREWORKS_BLAST1, this, 1.0D, 1.0D, 16);
               EntityLilith var15 = new EntityLilith(super.worldObj);
               var15.func_110163_bv();
               var15.copyLocationAndAnglesFrom(this);
               var15.onSpawnWithEgg((IEntityLivingData)null);
               super.worldObj.removeEntity(this);
               super.worldObj.spawnEntityInWorld(var15);
               var15.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1017, (int)var15.posX, (int)var15.posY, (int)var15.posZ, 0);
               EntityLivingBase j = this.getOwner();
               if(j != null && j instanceof EntityPlayer) {
                  ChatUtil.sendTranslated(EnumChatFormatting.DARK_PURPLE, (EntityPlayer)j, "item.witchery:glassgoblet.lilithquestsummon2", new Object[0]);
                  SoundEffect.WITCHERY_MOB_LILITH_TALK.playAt((EntityLiving)var15);
               }

               super.worldObj.createExplosion(var15, var15.posX, var15.posY, var15.posZ, 6.0F, true);
            }
         } else {
            double var16 = (double)this.getHomePosition().posX - super.posX;
            double k = (double)this.getHomePosition().posY - super.posY;
            double d2 = (double)this.getHomePosition().posZ - super.posZ;
            double d3 = var16 * var16 + k * k + d2 * d2;
            if(d3 > 0.0D) {
               d3 = (double)MathHelper.sqrt_double(d3);
               double waypointX = super.posX + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
               double waypointY = super.posY + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
               double waypointZ = super.posZ + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
               if(this.isCourseTraversable(waypointX, waypointY, waypointZ, d3)) {
                  super.motionX += var16 / d3 * 0.2D;
                  super.motionY += k / d3 * 0.2D;
                  super.motionZ += d2 / d3 * 0.2D;
               }
            }
         }
      } else {
         for(int var17 = 0; var17 < 10; ++var17) {
            int var18 = MathHelper.floor_double(super.posX + (double)super.rand.nextInt(30) - 15.0D);
            int var19 = MathHelper.floor_double(super.boundingBox.minY + (double)super.rand.nextInt(6) - 3.0D);
            int l = MathHelper.floor_double(super.posZ + (double)super.rand.nextInt(30) - 15.0D);
            if(isLavaPool(super.worldObj, var18, var19, l, 6)) {
               this.setHomeArea(var18, var19, l, 2);
               this.func_152115_b("");
               break;
            }
         }
      }

   }

   private static boolean isLavaPool(World world, int x, int y, int z, int max) {
      if(isLavaPoolColumn(world, x, y, z) && isLavaPoolColumn(world, x + 1, y, z) && isLavaPoolColumn(world, x - 1, y, z) && isLavaPoolColumn(world, x, y, z + 1) && isLavaPoolColumn(world, x, y, z - 1)) {
         int max2 = max * max;

         for(int dx = x - max; dx <= x + max; ++dx) {
            for(int dz = z - max; dz <= z + max; ++dz) {
               double dist = Coord.distanceSq((double)x, (double)y, (double)z, (double)dx, (double)y, (double)dz);
               if(dist <= (double)max2 && world.getBlock(dx, y, dz) != Blocks.lava) {
                  return false;
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private static boolean isLavaPoolColumn(World world, int x, int y, int z) {
      if(world.getBlock(x, y, z) == Blocks.lava && world.isAirBlock(x, y + 1, z) && world.isAirBlock(x, y + 2, z)) {
         byte depth = 4;

         for(int dy = y - depth; dy < dy; ++dy) {
            if(world.getBlock(x, y, z) != Blocks.lava) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public void setOwner(EntityPlayer player) {
      this.setTamed(true);
      this.setPathToEntity((PathEntity)null);
      this.setAttackTarget((EntityLivingBase)null);
      this.setHealth(20.0F);
      this.func_152115_b(player.getUniqueID().toString());
      super.worldObj.setEntityState(this, (byte)7);
   }

   public void readEntityFromNBT(NBTTagCompound nbtRoot) {
      super.readEntityFromNBT(nbtRoot);
      this.setFollowerType(nbtRoot.getInteger("FollowerType"));
   }

   public void writeToNBT(NBTTagCompound nbtRoot) {
      super.writeToNBT(nbtRoot);
      nbtRoot.setInteger("FollowerType", this.getFollowerType());
   }
}
