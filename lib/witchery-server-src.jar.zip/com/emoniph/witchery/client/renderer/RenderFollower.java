package com.emoniph.witchery.client.renderer;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderFollower extends RenderBiped {

   private final ModelBiped model;
   private static final ResourceLocation TEXTURE = new ResourceLocation("witchery", "textures/entities/lilithfol1.png");


   public RenderFollower(ModelBiped model) {
      this(model, 1.0F);
   }

   public RenderFollower(ModelBiped model, float scale) {
      super(model, 0.5F, scale);
      this.model = model;
   }

   protected ResourceLocation getEntityTexture(EntityLiving entity) {
      return TEXTURE;
   }

}
